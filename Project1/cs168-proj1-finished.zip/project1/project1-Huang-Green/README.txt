1. Shan Huang cs168-fa; Zach Green cs168-dq
2. Keeping udpating the cost table in each router consistent
3. For example, our router doesn't take link speed (bankwidth) or network delay into consideration, which can be improved.
4. Our code can handle link wieghts but not incremental updates.