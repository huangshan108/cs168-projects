"""
The network simulator.
Students are expected to use api and basics, and should stay out
of core.
"""
