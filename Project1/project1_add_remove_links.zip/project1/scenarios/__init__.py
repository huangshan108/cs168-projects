"""
Contains various network topologies and scenarios.
See help of individual scenarios for more info.
"""
